import os
import struct
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import tkinter.font as tkfont
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.backends import default_backend

# ============================================================
#  Crypto helpers (AES-GCM, PBKDF2)
# ============================================================

MAGIC = b"FENC"
VERSION = 1
SALT_SIZE = 16
NONCE_SIZE = 12
KEY_SIZE = 32  # AES-256
KDF_ITERATIONS = 200_000


def derive_key(password: str, salt: bytes) -> bytes:
    password_bytes = password.encode("utf-8")
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_SIZE,
        salt=salt,
        iterations=KDF_ITERATIONS,
        backend=default_backend(),
    )
    return kdf.derive(password_bytes)


def encrypt_file(input_path: str, password: str) -> str:
    if not password:
        raise ValueError("Password is required")

    with open(input_path, "rb") as f:
        data = f.read()

    salt = os.urandom(SALT_SIZE)
    key = derive_key(password, salt)
    aesgcm = AESGCM(key)
    nonce = os.urandom(NONCE_SIZE)
    ciphertext = aesgcm.encrypt(nonce, data, None)

    header = MAGIC + struct.pack("B", VERSION) + salt + nonce
    enc_data = header + ciphertext

    output_path = input_path + ".enc"
    with open(output_path, "wb") as f:
        f.write(enc_data)

    return output_path


def decrypt_file(input_path: str, password: str) -> str:
    with open(input_path, "rb") as f:
        enc_data = f.read()

    if len(enc_data) < len(MAGIC) + 1 + SALT_SIZE + NONCE_SIZE:
        raise ValueError("File too short or not a valid encrypted file")

    offset = 0
    magic = enc_data[offset: offset + len(MAGIC)]
    offset += len(MAGIC)
    if magic != MAGIC:
        raise ValueError("Invalid file format (magic header mismatch)")

    version = enc_data[offset]
    offset += 1
    if version != VERSION:
        raise ValueError("Unsupported file version")

    salt = enc_data[offset: offset + SALT_SIZE]
    offset += SALT_SIZE
    nonce = enc_data[offset: offset + NONCE_SIZE]
    offset += NONCE_SIZE
    ciphertext = enc_data[offset:]

    key = derive_key(password, salt)
    aesgcm = AESGCM(key)
    try:
        plaintext = aesgcm.decrypt(nonce, ciphertext, None)
    except Exception:
        raise ValueError("Invalid password or corrupted file")

    if input_path.endswith(".enc"):
        output_path = input_path[:-4]
    else:
        output_path = input_path + ".dec"

    with open(output_path, "wb") as f:
        f.write(plaintext)

    return output_path


# ============================================================
#  Themed Tkinter App
# ============================================================


class ThemedApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("File Encryption Tool")
        self.geometry("900x600")
        self.minsize(800, 500)

        # theme + language
        self.current_theme = tk.StringVar(value="dark")
        self.current_lang = tk.StringVar(value="EN")  # EN or AR

        self.style = ttk.Style(self)
        self.configure(bg="#111111")
        self.colors = {}

        # fonts that we can scale when window is large
        self.font_body = tkfont.Font(family="Segoe UI", size=11)
        self.font_muted = tkfont.Font(family="Segoe UI", size=10)
        self.font_heading = tkfont.Font(family="Segoe UI Semibold", size=16)
        self.font_title = tkfont.Font(family="Segoe UI Semibold", size=18)
        self.font_button = tkfont.Font(family="Segoe UI", size=11)

        # main container fills window
        self.main_container = ttk.Frame(self, style="Main.TFrame")
        self.main_container.pack(expand=True, fill="both")

        # make grid in main_container expandable so pages fill it
        self.main_container.rowconfigure(0, weight=1)
        self.main_container.columnconfigure(0, weight=1)

        # pages
        self.pages = {}
        for PageClass in (HomePage, EncryptPage, DecryptPage):
            page = PageClass(self.main_container, self)
            self.pages[PageClass.__name__] = page
            page.grid(row=0, column=0, sticky="nsew")

        self.settings_window = None

        self.apply_theme()
        self.update_language()
        self.show_page("HomePage")

        # scale fonts when window size changes
        self.bind("<Configure>", self.on_root_resize)

    # -------------------- Navigation --------------------

    def show_page(self, name: str):
        page = self.pages[name]
        page.tkraise()

    def open_settings(self):
        if self.settings_window and tk.Toplevel.winfo_exists(self.settings_window):
            self.settings_window.lift()
            return
        self.settings_window = SettingsWindow(self)
        self.apply_theme_to_window(self.settings_window)
        self.settings_window.update_texts()

    # -------------------- Theme System --------------------

    def apply_theme(self):
        theme = self.current_theme.get()

        if theme == "dark":
            bg = "#111111"
            card = "#26282A"
            card_alt = "#2F3234"
            text = "#FFFFFF"
            text_muted = "#C9CDD1"
            primary = "#3A7CFF"
            primary_hover = "#3165CC"
            border = "#383B3E"
            success_bg = "#1C3D28"
            success_fg = "#8FF0A4"
            error_bg = "#3D1C1C"
            error_fg = "#FF7B7B"
        else:
            # softer light theme; card & buttons a bit darker than background
            bg = "#F3F5F7"
            card = "#E7ECF3"
            card_alt = "#D8DFEC"
            text = "#1A1A1A"
            text_muted = "#5A5F65"
            primary = "#3A7CFF"
            primary_hover = "#3165CC"
            border = "#C4CBD8"
            success_bg = "#E5F7EB"
            success_fg = "#107C41"
            error_bg = "#FDE8E8"
            error_fg = "#B91C1C"

        self.colors = {
            "bg": bg,
            "card": card,
            "card_alt": card_alt,
            "text": text,
            "text_muted": text_muted,
            "primary": primary,
            "primary_hover": primary_hover,
            "border": border,
            "success_bg": success_bg,
            "success_fg": success_fg,
            "error_bg": error_bg,
            "error_fg": error_fg,
        }

        self.configure(bg=bg)
        self.style.theme_use("clam")

        self.style.configure("Main.TFrame", background=bg)
        self.style.configure("Card.TFrame", background=card, borderwidth=0)

        self.style.configure(
            "Title.TLabel",
            background=card,
            foreground=text,
            font=self.font_title,
        )
        self.style.configure(
            "Heading.TLabel",
            background=card,
            foreground=text,
            font=self.font_heading,
        )
        self.style.configure(
            "TLabel",
            background=card,
            foreground=text,
            font=self.font_body,
        )
        self.style.configure(
            "Muted.TLabel",
            background=card,
            foreground=text_muted,
            font=self.font_muted,
        )

        self.style.configure(
            "Primary.TButton",
            background=primary,
            foreground="#FFFFFF",
            font=self.font_button,
            borderwidth=0,
            focusthickness=0,
            padding=(16, 8),
        )
        self.style.map(
            "Primary.TButton",
            background=[("active", primary_hover)],
        )

        self.style.configure(
            "Secondary.TButton",
            background=card_alt,
            foreground=text,
            font=self.font_button,
            borderwidth=0,
            focusthickness=0,
            padding=(16, 8),
        )
        self.style.map(
            "Secondary.TButton",
            background=[("active", border)],
        )

        self.style.configure(
            "TEntry",
            padding=6,
            fieldbackground=card_alt,
            foreground=text,
            bordercolor=border,
            lightcolor=border,
            darkcolor=border,
            borderwidth=1,
            relief="solid",
        )

        self.style.configure(
            "Status.TLabel",
            background=card_alt,
            foreground=text_muted,
            font=self.font_muted,
        )
        self.style.configure(
            "Success.TLabel",
            background=success_bg,
            foreground=success_fg,
            font=self.font_muted,
        )
        self.style.configure(
            "Error.TLabel",
            background=error_bg,
            foreground=error_fg,
            font=self.font_muted,
        )

        self.main_container.configure(style="Main.TFrame")

        for page in self.pages.values():
            page.apply_theme()

        if self.settings_window and tk.Toplevel.winfo_exists(self.settings_window):
            self.apply_theme_to_window(self.settings_window)

    def apply_theme_to_window(self, window):
        colors = self.colors
        window.configure(bg=colors["bg"])
        for child in window.winfo_children():
            try:
                child.configure(style="Main.TFrame")
            except tk.TclError:
                pass

    # -------------------- Language System --------------------

    def update_language(self):
        for page in self.pages.values():
            if hasattr(page, "set_texts"):
                page.set_texts()

        if self.settings_window and tk.Toplevel.winfo_exists(self.settings_window):
            self.settings_window.update_texts()

    # -------------------- Font scaling on resize --------------------

    def on_root_resize(self, event):
        w, h = event.width, event.height
        # simple 3-step scaling
        if w > 1400 or h > 850:
            scale = 1.3
        elif w > 1100 or h > 650:
            scale = 1.15
        else:
            scale = 1.0

        base_body = 11
        base_muted = 10
        base_heading = 16
        base_title = 18
        base_button = 11

        self.font_body.configure(size=int(base_body * scale))
        self.font_muted.configure(size=int(base_muted * scale))
        self.font_heading.configure(size=int(base_heading * scale))
        self.font_title.configure(size=int(base_title * scale))
        self.font_button.configure(size=int(base_button * scale))


# ============================================================
#  Base Page (center card with grid)
# ============================================================

class BasePage(ttk.Frame):
    def __init__(self, parent, app: ThemedApp):
        super().__init__(parent, style="Main.TFrame")
        self.app = app

        # one inner frame that takes all the space
        self.inner = ttk.Frame(self, style="Main.TFrame")
        self.inner.grid(row=0, column=0, sticky="nsew")

        # center the card inside 'inner'
        self.inner.grid_rowconfigure(0, weight=1)
        self.inner.grid_columnconfigure(0, weight=1)

        # main card – its natural size will grow with fonts
        self.card = ttk.Frame(self.inner, style="Card.TFrame", padding=24)
        self.card.grid(row=0, column=0)  # no sticky -> centered

        # let this page fill main_container
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

    def apply_theme(self):
        # pages can override if needed
        pass

    def set_texts(self):
        # pages override for EN/AR text
        pass


# ============================================================
#  Home Page
# ============================================================


class HomePage(BasePage):
    def __init__(self, parent, app: ThemedApp):
        super().__init__(parent, app)

        self.card.grid_columnconfigure(0, weight=1)

        self.icon_label = ttk.Label(self.card, text="🔒", font=("Segoe UI", 32))
        self.icon_label.grid(row=0, column=0, pady=(8, 4), columnspan=2)

        self.title_label = ttk.Label(self.card, style="Title.TLabel")
        self.title_label.grid(row=1, column=0, columnspan=2, pady=(0, 24))

        self.encrypt_btn = ttk.Button(
            self.card,
            style="Primary.TButton",
            command=lambda: app.show_page("EncryptPage"),
        )
        self.encrypt_btn.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 8))

        self.decrypt_btn = ttk.Button(
            self.card,
            style="Secondary.TButton",
            command=lambda: app.show_page("DecryptPage"),
        )
        self.decrypt_btn.grid(row=3, column=0, columnspan=2, sticky="ew")

        self.settings_btn = ttk.Button(
            self.card, text="⚙", width=3, command=app.open_settings
        )
        self.settings_btn.grid(row=0, column=1, sticky="ne")

        lang_frame = ttk.Frame(self, style="Main.TFrame", padding=(0, 16))
        lang_frame.place(relx=0.5, rely=1.0, anchor="s")  # center bottom
        self.lang_en_btn = ttk.Button(
            lang_frame,
            text="EN",
            style="Secondary.TButton",
            command=lambda: self.set_language("EN"),
        )
        self.lang_ar_btn = ttk.Button(
            lang_frame,
            text="AR",
            style="Secondary.TButton",
            command=lambda: self.set_language("AR"),
        )
        self.lang_en_btn.grid(row=0, column=0, padx=(0, 2))
        self.lang_ar_btn.grid(row=0, column=1, padx=(2, 0))

        self.set_texts()
        self.apply_theme()

    def set_language(self, lang_code: str):
        self.app.current_lang.set(lang_code)
        self.app.update_language()
        self.apply_theme()

    def apply_theme(self):
        self.card.configure(style="Card.TFrame")
        if self.app.current_lang.get() == "EN":
            self.lang_en_btn.configure(style="Primary.TButton")
            self.lang_ar_btn.configure(style="Secondary.TButton")
        else:
            self.lang_en_btn.configure(style="Secondary.TButton")
            self.lang_ar_btn.configure(style="Primary.TButton")

    def set_texts(self):
        if self.app.current_lang.get() == "EN":
            self.title_label.config(text="File Encryption Tool")
            self.encrypt_btn.config(text="Encrypt File")
            self.decrypt_btn.config(text="Decrypt File")
        else:
            self.title_label.config(text="أداة تشفير الملفات")
            self.encrypt_btn.config(text="تشفير ملف")
            self.decrypt_btn.config(text="فك تشفير ملف")


# ============================================================
#  Encrypt Page
# ============================================================


class EncryptPage(BasePage):
    def __init__(self, parent, app: ThemedApp):
        super().__init__(parent, app)

        self.card.grid_columnconfigure(0, weight=1)
        self.card.grid_columnconfigure(1, weight=1)

        self.selected_file = tk.StringVar(value="No file selected")
        self.password_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Status messages will appear here...")

        self.back_btn = ttk.Button(
            self.card,
            text="←",
            style="Secondary.TButton",
            width=3,
            command=lambda: app.show_page("HomePage"),
        )
        self.back_btn.grid(row=0, column=0, sticky="w")

        self.title = ttk.Label(self.card, style="Heading.TLabel")
        self.title.grid(row=1, column=0, columnspan=3, pady=(8, 16), sticky="w")

        file_frame = ttk.Frame(self.card, style="Card.TFrame")
        file_frame.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(0, 16))
        file_frame.grid_columnconfigure(1, weight=1)

        self.file_icon = ttk.Label(file_frame, text="📄")
        self.file_icon.grid(row=0, column=0, padx=(0, 6))

        self.file_label = ttk.Label(
            file_frame,
            textvariable=self.selected_file,
            style="Muted.TLabel",
        )
        self.file_label.grid(row=0, column=1, sticky="w")

        self.select_btn = ttk.Button(
            file_frame,
            style="Secondary.TButton",
            command=self.browse_file,
        )
        self.select_btn.grid(row=0, column=2, padx=(8, 0))

        self.pw_label = ttk.Label(self.card)
        self.pw_label.grid(row=3, column=0, sticky="w")

        pw_frame = ttk.Frame(self.card, style="Card.TFrame")
        pw_frame.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(4, 16))
        pw_frame.grid_columnconfigure(0, weight=1)

        self.pw_entry = ttk.Entry(
            pw_frame,
            show="*",
            textvariable=self.password_var,
            width=40,
        )
        self.pw_entry.grid(row=0, column=0, sticky="ew")

        self.show_password = False

        def toggle_pw():
            self.show_password = not self.show_password
            self.pw_entry.configure(show="" if self.show_password else "*")

        self.pw_toggle = ttk.Button(
            pw_frame,
            text="👁",
            width=3,
            style="Secondary.TButton",
            command=toggle_pw,
        )
        self.pw_toggle.grid(row=0, column=1, padx=(6, 0))

        self.encrypt_btn = ttk.Button(
            self.card,
            style="Primary.TButton",
            command=self.handle_encrypt,
        )
        self.encrypt_btn.grid(row=5, column=0, columnspan=3, sticky="ew", pady=(0, 16))

        self.status_label = ttk.Label(
            self.card,
            textvariable=self.status_var,
            style="Status.TLabel",
            anchor="center",
        )
        self.status_label.grid(row=6, column=0, columnspan=3, sticky="ew")

        self.set_texts()

    def browse_file(self):
        path = filedialog.askopenfilename()
        if path:
            self.selected_file.set(path)

    def handle_encrypt(self):
        path = self.selected_file.get()
        password = self.password_var.get()
        lang = self.app.current_lang.get()

        if path == "No file selected":
            self.status_var.set(
                "Please select a file to encrypt."
                if lang == "EN"
                else "يرجى اختيار ملف للتشفير."
            )
            return
        if not password:
            self.status_var.set(
                "Please enter a password."
                if lang == "EN"
                else "يرجى إدخال كلمة مرور."
            )
            return
        try:
            output_path = encrypt_file(path, password)
            msg = (
                f"File encrypted successfully:\n{output_path}"
                if lang == "EN"
                else f"تم تشفير الملف بنجاح:\n{output_path}"
            )
            self.status_var.set(msg)
            SuccessModal(
                self.app,
                "File encrypted successfully."
                if lang == "EN"
                else "تم تشفير الملف بنجاح.",
            )
        except Exception as e:
            self.status_var.set(
                f"Error: {e}" if lang == "EN" else f"خطأ: {e}"
            )
            messagebox.showerror("Encryption Error", str(e))

    def set_texts(self):
        if self.app.current_lang.get() == "EN":
            self.title.config(text="Encrypt a File")
            self.select_btn.config(text="Select File")
            self.pw_label.config(text="Set Password")
            self.encrypt_btn.config(text="Encrypt")
            if self.status_var.get().startswith("Status messages") or self.status_var.get() == "":
                self.status_var.set("Status messages will appear here...")
        else:
            self.title.config(text="تشفير ملف")
            self.select_btn.config(text="اختر ملف")
            self.pw_label.config(text="كلمة المرور")
            self.encrypt_btn.config(text="تشفير")
            if self.status_var.get().startswith("Status messages") or self.status_var.get() == "":
                self.status_var.set("ستظهر رسائل الحالة هنا...")

    def apply_theme(self):
        pass


# ============================================================
#  Decrypt Page
# ============================================================


class DecryptPage(BasePage):
    def __init__(self, parent, app: ThemedApp):
        super().__init__(parent, app)

        self.card.grid_columnconfigure(0, weight=1)

        self.selected_file = tk.StringVar(value="No file selected")
        self.password_var = tk.StringVar()

        self.back_btn = ttk.Button(
            self.card,
            text="←",
            style="Secondary.TButton",
            width=3,
            command=lambda: app.show_page("HomePage"),
        )
        self.back_btn.grid(row=0, column=0, sticky="w")

        self.title = ttk.Label(self.card, style="Heading.TLabel")
        self.title.grid(row=1, column=0, columnspan=3, pady=(8, 0), sticky="w")

        self.subtitle = ttk.Label(self.card, style="Muted.TLabel")
        self.subtitle.grid(row=2, column=0, columnspan=3, pady=(0, 16), sticky="w")

        file_frame = ttk.Frame(self.card, style="Card.TFrame")
        file_frame.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(0, 8))
        file_frame.grid_columnconfigure(0, weight=1)

        self.select_btn = ttk.Button(
            file_frame,
            style="Secondary.TButton",
            command=self.browse_file,
        )
        self.select_btn.grid(row=0, column=0, sticky="ew")

        self.file_path_label = ttk.Label(
            self.card,
            textvariable=self.selected_file,
            style="Muted.TLabel",
        )
        self.file_path_label.grid(row=4, column=0, columnspan=3, sticky="w", pady=(0, 12))

        self.pw_label = ttk.Label(self.card)
        self.pw_label.grid(row=5, column=0, sticky="w")

        pw_frame = ttk.Frame(self.card, style="Card.TFrame")
        pw_frame.grid(row=6, column=0, columnspan=3, sticky="ew", pady=(4, 12))
        pw_frame.grid_columnconfigure(0, weight=1)

        self.pw_entry = ttk.Entry(
            pw_frame,
            show="*",
            textvariable=self.password_var,
        )
        self.pw_entry.grid(row=0, column=0, sticky="ew")

        self.show_password = False

        def toggle_pw():
            self.show_password = not self.show_password
            self.pw_entry.configure(show="" if self.show_password else "*")

        self.pw_toggle = ttk.Button(
            pw_frame,
            text="👁",
            width=3,
            style="Secondary.TButton",
            command=toggle_pw,
        )
        self.pw_toggle.grid(row=0, column=1, padx=(6, 0))

        self.decrypt_btn = ttk.Button(
            self.card,
            style="Primary.TButton",
            command=self.handle_decrypt,
        )
        self.decrypt_btn.grid(row=7, column=0, columnspan=3, sticky="ew", pady=(0, 12))

        self.success_var = tk.StringVar(value="")
        self.error_var = tk.StringVar(value="")

        self.success_label = ttk.Label(
            self.card,
            textvariable=self.success_var,
            style="Success.TLabel",
            anchor="w",
        )
        self.success_label.grid(row=8, column=0, columnspan=3, sticky="ew", pady=(0, 4))

        self.error_label = ttk.Label(
            self.card,
            textvariable=self.error_var,
            style="Error.TLabel",
            anchor="w",
        )
        self.error_label.grid(row=9, column=0, columnspan=3, sticky="ew")

        self.set_texts()

    def browse_file(self):
        path = filedialog.askopenfilename(
            filetypes=[("Encrypted files", "*.enc"), ("All files", "*.*")]
        )
        if path:
            self.selected_file.set(path)

    def handle_decrypt(self):
        path = self.selected_file.get()
        password = self.password_var.get()
        lang = self.app.current_lang.get()

        self.success_var.set("")
        self.error_var.set("")

        if path == "No file selected":
            self.error_var.set(
                "Please select an encrypted .enc file."
                if lang == "EN"
                else "يرجى اختيار ملف .enc مشفّر."
            )
            return
        if not password:
            self.error_var.set(
                "Please enter your decryption password."
                if lang == "EN"
                else "يرجى إدخال كلمة مرور فك التشفير."
            )
            return

        try:
            output_path = decrypt_file(path, password)
            self.success_var.set(
                f"Success – file restored:\n{output_path}"
                if lang == "EN"
                else f"تم فك التشفير – تم استرجاع الملف:\n{output_path}"
            )
            self.error_var.set("")
            SuccessModal(
                self.app,
                "File decrypted successfully."
                if lang == "EN"
                else "تم فك تشفير الملف بنجاح.",
            )
        except Exception as e:
            self.error_var.set(
                f"Decryption failed: {e}"
                if lang == "EN"
                else f"فشل فك التشفير: {e}"
            )
            self.success_var.set("")

    def set_texts(self):
        if self.app.current_lang.get() == "EN":
            self.title.config(text="Decrypt a File")
            self.subtitle.config(text="Select a file and enter the password to decrypt it.")
            self.select_btn.config(text="Select .enc File")
            self.pw_label.config(text="Password")
            self.decrypt_btn.config(text="Decrypt")
        else:
            self.title.config(text="فك تشفير ملف")
            self.subtitle.config(text="اختر ملفًا وأدخل كلمة المرور لفك تشفيره.")
            self.select_btn.config(text="اختر ملف .enc")
            self.pw_label.config(text="كلمة المرور")
            self.decrypt_btn.config(text="فك التشفير")

    def apply_theme(self):
        pass


# ============================================================
#  Settings Window
# ============================================================


class SettingsWindow(tk.Toplevel):
    def __init__(self, app: ThemedApp):
        super().__init__(app)
        self.app = app
        self.title("Settings")
        self.geometry("600x420")
        self.minsize(520, 380)
        self.resizable(True, True)

        # outer frame
        outer = ttk.Frame(self, style="Main.TFrame")
        outer.pack(expand=True, fill="both")

        # card centered
        self.card = ttk.Frame(outer, style="Card.TFrame", padding=24)
        self.card.place(relx=0.5, rely=0.5, anchor="center")
        self.card.grid_columnconfigure(0, weight=1)

        header_frame = ttk.Frame(self.card, style="Card.TFrame")
        header_frame.grid(row=0, column=0, sticky="ew")
        header_frame.grid_columnconfigure(0, weight=1)

        self.title_label = ttk.Label(header_frame, style="Heading.TLabel")
        self.title_label.grid(row=0, column=0, sticky="w")

        close_btn = ttk.Button(
            header_frame,
            text="✕",
            width=3,
            style="Secondary.TButton",
            command=self.destroy,
        )
        close_btn.grid(row=0, column=1, sticky="e")

        row = 1
        self.appearance_label = ttk.Label(self.card, style="Heading.TLabel")
        self.appearance_label.grid(row=row, column=0, sticky="w", pady=(16, 4))
        row += 1

        theme_frame = ttk.Frame(self.card, style="Card.TFrame")
        theme_frame.grid(row=row, column=0, sticky="w", pady=(0, 12))
        ttk.Label(theme_frame, text="Theme").grid(row=0, column=0, padx=(0, 12))

        self.light_btn = ttk.Button(
            theme_frame,
            text="Light",
            style="Secondary.TButton",
            command=lambda: self.set_theme("light"),
        )
        self.dark_btn = ttk.Button(
            theme_frame,
            text="Dark",
            style="Secondary.TButton",
            command=lambda: self.set_theme("dark"),
        )
        self.light_btn.grid(row=0, column=1, padx=(0, 4))
        self.dark_btn.grid(row=0, column=2)

        row += 1
        self.general_label = ttk.Label(self.card, style="Heading.TLabel")
        self.general_label.grid(row=row, column=0, sticky="w", pady=(16, 4))
        row += 1

        lang_frame = ttk.Frame(self.card, style="Card.TFrame")
        lang_frame.grid(row=row, column=0, sticky="w")
        self.lang_label = ttk.Label(lang_frame)
        self.lang_label.grid(row=0, column=0, padx=(0, 12))

        self.lang_combo = ttk.Combobox(
            lang_frame,
            values=["English", "Arabic"],
            state="readonly",
            width=10,
        )
        self.lang_combo.set(
            "English" if self.app.current_lang.get() == "EN" else "Arabic"
        )
        self.lang_combo.grid(row=0, column=1)
        self.lang_combo.bind("<<ComboboxSelected>>", self.on_language_change)

        row += 1
        self.about_label = ttk.Label(self.card, style="Heading.TLabel")
        self.about_label.grid(row=row, column=0, sticky="w", pady=(16, 4))
        row += 1

        about_frame = ttk.Frame(self.card, style="Card.TFrame")
        about_frame.grid(row=row, column=0, sticky="ew")
        about_frame.grid_columnconfigure(0, weight=1)

        self.help_btn = ttk.Button(
            about_frame,
            style="Secondary.TButton",
            command=self.show_help,
        )
        self.help_btn.grid(row=0, column=0, sticky="w", pady=(0, 4))

        self.about_app_btn = ttk.Button(
            about_frame,
            style="Secondary.TButton",
            command=self.show_about_app,
        )
        self.about_app_btn.grid(row=1, column=0, sticky="w", pady=(0, 4))

        self.licenses_btn = ttk.Button(
            about_frame,
            style="Secondary.TButton",
            command=self.show_licenses,
        )
        self.licenses_btn.grid(row=2, column=0, sticky="w")

        self.footer = ttk.Label(
            self.card,
            text="Version 1.0.0",
            style="Muted.TLabel",
        )
        self.footer.grid(row=row + 1, column=0, sticky="e", pady=(16, 0))

        self.update_theme_buttons()

    def set_theme(self, theme: str):
        self.app.current_theme.set(theme)
        self.app.apply_theme()
        self.update_theme_buttons()

    def update_theme_buttons(self):
        if self.app.current_theme.get() == "dark":
            self.dark_btn.configure(style="Primary.TButton")
            self.light_btn.configure(style="Secondary.TButton")
        else:
            self.light_btn.configure(style="Primary.TButton")
            self.dark_btn.configure(style="Secondary.TButton")

    def on_language_change(self, event=None):
        # change app language immediately when dropdown is changed
        lang = self.lang_combo.get()
        self.app.current_lang.set("EN" if lang == "English" else "AR")
        self.app.update_language()

    def update_texts(self):
        if self.app.current_lang.get() == "EN":
            self.title_label.config(text="Settings")
            self.appearance_label.config(text="Appearance")
            self.general_label.config(text="General")
            self.about_label.config(text="About")
            self.lang_label.config(text="Language")
            self.help_btn.config(text="Help & Support")
            self.about_app_btn.config(text="About Application")
            self.licenses_btn.config(text="Licenses")
            self.lang_combo.set(
                "English" if self.app.current_lang.get() == "EN" else "Arabic"
            )
        else:
            self.title_label.config(text="الإعدادات")
            self.appearance_label.config(text="المظهر")
            self.general_label.config(text="عام")
            self.about_label.config(text="حول")
            self.lang_label.config(text="اللغة")
            self.help_btn.config(text="المساعدة والدعم")
            self.about_app_btn.config(text="حول التطبيق")
            self.licenses_btn.config(text="التراخيص")
            self.lang_combo.set(
                "English" if self.app.current_lang.get() == "EN" else "Arabic"
            )

    def show_help(self):
        msg_en = (
            "If you need help or support, please contact:\n\n"
            "azzam.vip.b@gmail.com\n"
        )
        msg_ar = (
            "للمساعدة أو الدعم، تواصل مع:\n\n"
            "azzam.vip.b@gmail.com\n"
        )
        messagebox.showinfo(
            "Help & Support" if self.app.current_lang.get() == "EN" else "المساعدة والدعم",
            msg_en if self.app.current_lang.get() == "EN" else msg_ar,
        )

    def show_about_app(self):
        msg_en = (
            "File Encryption Tool\n\n"
            "This application lets you securely encrypt and decrypt files using AES-GCM.\n\n"
            "How to use:\n"
            "1. From the Home screen, choose Encrypt or Decrypt.\n"
            "2. Select your file.\n"
            "3. Enter a strong password.\n"
            "4. Click Encrypt to create a .enc file or Decrypt to restore the original file.\n\n"
            "All operations happen locally on your device."
        )
        msg_ar = (
            "أداة تشفير الملفات\n\n"
            "تسمح لك هذه الأداة بتشفير وفك تشفير الملفات بأمان باستخدام AES-GCM.\n\n"
            "طريقة الاستخدام:\n"
            "1. من الشاشة الرئيسية اختر (تشفير) أو (فك التشفير).\n"
            "2. اختر الملف المطلوب.\n"
            "3. أدخل كلمة مرور قوية.\n"
            "4. اضغط (تشفير) لإنشاء ملف .enc أو (فك التشفير) لاسترجاع الملف الأصلي.\n\n"
            "جميع العمليات تتم محليًا على جهازك."
        )
        messagebox.showinfo(
            "About Application" if self.app.current_lang.get() == "EN" else "حول التطبيق",
            msg_en if self.app.current_lang.get() == "EN" else msg_ar,
        )

    def show_licenses(self):
        msg = (
            "File Encryption Tool\n"
            "Copyright © 2025 Azzam Alshamrani. All rights reserved.\n\n"
            "This application uses the Python 'cryptography' library for AES-GCM\n"
            "encryption and Tkinter for the graphical user interface.\n"
            "You may NOT modify this project.\n"
        )
        messagebox.showinfo("Licenses", msg)


# ============================================================
#  Success Modal
# ============================================================


class SuccessModal(tk.Toplevel):
    def __init__(self, app: ThemedApp, message: str):
        super().__init__(app)
        self.app = app
        self.title("Success")
        self.resizable(False, False)

        colors = app.colors
        self.configure(bg=colors["bg"])

        card = ttk.Frame(self, style="Card.TFrame", padding=24)
        card.pack(expand=True, fill="both", padx=40, pady=40)

        icon_label = ttk.Label(card, text="✅", font=("Segoe UI", 28))
        icon_label.grid(row=0, column=0, pady=(0, 16))

        title_text = "Success!" if app.current_lang.get() == "EN" else "تم بنجاح!"
        title_label = ttk.Label(card, text=title_text, style="Heading.TLabel")
        title_label.grid(row=1, column=0, pady=(0, 4))

        msg_label = ttk.Label(card, text=message, style="Muted.TLabel")
        msg_label.grid(row=2, column=0, pady=(0, 16))

        ok_text = "Done" if app.current_lang.get() == "EN" else "تم"
        ok_btn = ttk.Button(
            card,
            text=ok_text,
            style="Primary.TButton",
            command=self.destroy,
        )
        ok_btn.grid(row=3, column=0, sticky="ew")

        self.update_idletasks()
        x = app.winfo_x() + (app.winfo_width() // 2 - self.winfo_width() // 2)
        y = app.winfo_y() + (app.winfo_height() // 2 - self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")


# ============================================================
#  Run the app
# ============================================================


if __name__ == "__main__":
    app = ThemedApp()
    app.mainloop()
